"use client"

import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"

export default function Footer() {
  const [isDarkMode, setIsDarkMode] = useState(false)

  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark")
    } else {
      document.body.classList.remove("dark")
    }
  }, [isDarkMode])

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4 text-center">
        <p className="mb-4">&copy; 2024 Language Learning Platform. All rights reserved.</p>
        <Button variant="outline" onClick={toggleDarkMode}>
          Toggle Dark Mode
        </Button>
      </div>
    </footer>
  )
}

