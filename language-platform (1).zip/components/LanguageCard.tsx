"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"

interface LanguageCardProps {
  name: string
  level: string
  image: string
}

export default function LanguageCard({ name, level, image }: LanguageCardProps) {
  return (
    <motion.div
      className="bg-white rounded-lg shadow-lg overflow-hidden"
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.2 }}
    >
      <Image
        src={image || "/placeholder.svg"}
        alt={name}
        width={200}
        height={200}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h2 className="text-xl font-semibold text-indigo-800 mb-2">{name}</h2>
        <p className="text-indigo-600 mb-4">{level}</p>
        <Button className="w-full">Start Learning</Button>
      </div>
    </motion.div>
  )
}

