"use client"

import { motion, AnimatePresence } from "framer-motion"
import { useState, useEffect } from "react"

const words = ["Learn", "Explore", "Grow", "Connect", "Achieve"]

export default function AnimatedBackgroundText() {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % words.length)
    }, 3000) // Change word every 3 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.h2
          key={words[index]}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 0.1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          transition={{ duration: 0.5 }}
          className="text-[20vw] font-bold text-white pointer-events-none select-none"
        >
          {words[index]}
        </motion.h2>
      </AnimatePresence>
    </div>
  )
}

