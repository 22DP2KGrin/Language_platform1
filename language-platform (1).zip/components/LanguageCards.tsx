"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"

const languages = [
  { name: "English", image: "/english.jpg" },
  { name: "Spanish", image: "/spanish.jpg" },
  { name: "French", image: "/french.jpg" },
  { name: "German", image: "/german.jpg" },
  { name: "Chinese", image: "/chinese.jpg" },
  { name: "Japanese", image: "/japanese.jpg" },
]

export default function LanguageCards() {
  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Choose Your Language</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {languages.map((language, index) => (
            <motion.div
              key={language.name}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden">
                <Image
                  src={language.image || "/placeholder.svg"}
                  alt={language.name}
                  width={400}
                  height={200}
                  className="w-full h-48 object-cover"
                />
                <CardHeader>
                  <CardTitle>{language.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <Button className="w-full">Start Learning</Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

