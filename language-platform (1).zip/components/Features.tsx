"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, BookOpen, MessageCircle } from "lucide-react"

const features = [
  {
    icon: Users,
    title: "Expert Tutors",
    description: "Work with language professionals to guide you to fluency.",
  },
  {
    icon: BookOpen,
    title: "Interactive Lessons",
    description: "Engage with lessons tailored to your needs and learning style.",
  },
  {
    icon: MessageCircle,
    title: "Community Support",
    description: "Collaborate with fellow learners and receive helpful feedback.",
  },
]

export default function Features() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <feature.icon className="w-6 h-6 mr-2 text-indigo-600" />
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p>{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

