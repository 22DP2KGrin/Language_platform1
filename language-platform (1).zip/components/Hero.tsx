"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import AnimatedBackgroundText from "./AnimatedBackgroundText"

export default function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden animated-bg">
      <AnimatedBackgroundText />
      <div className="relative z-10 text-center">
        <motion.h2
          className="text-5xl font-bold mb-4 text-white"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Level Up Your Language Skills
        </motion.h2>
        <motion.p
          className="text-xl mb-8 text-white"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          Join our immersive platform to boost your language abilities through interactive lessons and community
          support.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <Button size="lg">Get Started Now</Button>
        </motion.div>
      </div>
    </section>
  )
}

