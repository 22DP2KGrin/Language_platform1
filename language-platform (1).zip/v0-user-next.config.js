/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
}

module.exports = {
  ...nextConfig,
  async rewrites() {
    return [
      // Add any rewrites here if needed
    ]
  },
  // Add this to specify a custom port
  serverOptions: {
    port: 3333, // You can choose any available port number
  },
}

